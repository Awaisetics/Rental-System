
       
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('adminpanel/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(URL::asset('adminpanel/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(URL::asset('adminpanel/build/js/custom.min.js')); ?>"></script>
	
  </body>
</html>
<?php /**PATH /home/muneeb/Desktop/rentalsystem/resources/views/components/adminfooter.blade.php ENDPATH**/ ?>