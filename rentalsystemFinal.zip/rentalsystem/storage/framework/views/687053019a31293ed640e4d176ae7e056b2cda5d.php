<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => ['title' => 'Product Page']]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Product Page']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<!-- Page Add Section Begin -->
<br><br><br>
<section class="page-add">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="page-breadcrumb">
                    <h2><?php echo e($pro->name); ?><span>.</span></h2>

                    <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                    <a href=""><?php echo e($cat->name); ?></a>
                    <a class="active" href="<?php echo e(URL::to('product_page/' . $pro['id'])); ?>"><?php echo e($pro->name); ?></a>

                </div>
            </div>

        </div>
    </div>
</section>
<!-- Page Add Section End -->

<!-- Product Page Section Beign -->
<section class="product-page">
    <div class="container">

        <div class="row">
            <div class="col-lg-6">
                <div class="product-slider owl-carousel">
                    <div class="product-img">
                        <figure>
                            <img src="<?php echo e(URL::asset('img/product/' . $pro['img1'])); ?>" alt="Image1">

                        </figure>

                    </div>
                    <div class="product-img">
                        <figure>
                            <img src="<?php echo e(URL::asset('img/product/' . $pro['img2'])); ?>" alt="Image2">

                        </figure>
                    </div>
                </div>

            </div>
            <div class="col-lg-6">
                <div class="product-content">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>


                    <h2><?php echo e($pro->name); ?></h2>
                    <div class="pc-meta">
                        <h5>Rs. <?php echo e($pro->price); ?> /day</h5>

                    </div>
                    <p><?php echo e($pro->details); ?></p>
                    <ul class="tags">
                        <li><span>Category :</span> <?php echo e($cat->name); ?></li>
                        <li><span>Shop Name :</span> <?php echo e($shop->shopname); ?></li>
                    </ul>
                    <form action="<?php echo e(URL::to('addToCart')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="proid" value="<?php echo e($pro->id); ?>">
                        <input type="hidden" name="path" value="<?php echo e(Request::path()); ?>">
                        <input type="hidden" name="price" value="<?php echo e($pro->price); ?>">
                        
                        <label for="start" class="font-weight-bold">Start:</label>
                        <input type="date" name="startdate">
                        <span class="text-danger"><?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        <br>
                        <label for="last" class="font-weight-bold">Last : </label>
                        <input type="date" name="enddate">
                        <span class="text-danger"><?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        <br>
                        <div class="product-quantity mt-2">
                            <div class="pro-qty">
                                <input type="text" value="1" name="quantity">
                                <span class="text-danger"><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Add To Cart">
                    </form>
                    <br><br><br>
                </div>
            </div>
        </div>
    </div>
</section>
<hr>

<!-- Product Page Section End -->

<!-- Related Product Section Begin -->
<section class="related-product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="section-title">
                    <h2>Related Products</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $RelatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value['id'] != $pro->id): ?>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-product-item img-thumbnail">
                            <figure>
                                <a href="<?php echo e(URL::to('product_page/' . $value['id'])); ?>"><img
                                        src="<?php echo e(URL::asset('img/product/' . $value['img1'])); ?>" alt=""></a>
                                
                            </figure>
                            <div class="product-text">
                                <h6><?php echo e($value['name']); ?></h6>
                                <p><?php echo e($value['price']); ?></p>
                                <a href="<?php echo e(URL::to('product_page/' . $value['id'])); ?>"><button
                                        class="btn btn-outline-primary mt-2 mb-3">View Product</button></a>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</section>
<!-- Related Product Section End -->

<!-- Footer Section Begin -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/muneeb/Desktop/rentalsystem/resources/views/website/product-page.blade.php ENDPATH**/ ?>