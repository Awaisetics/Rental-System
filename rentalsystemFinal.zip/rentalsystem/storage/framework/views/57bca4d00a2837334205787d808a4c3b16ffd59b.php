<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminheader','data' => ['title' => 'Products']]); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Products']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Products Tables <small></h3>
            </div>

        </div>
        <br><br><br>

        <div class="table-responsive bg-white">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr style="color:black">
                        <th>#</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Details</th>
                        <th>Sub Category</th>
                        <th>Quantity</th>
                        <th>Image</th>
                        <th>Shop</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="color:black">
                            <th scope="row"><?php echo e($i); ?></th>
                            <td class="text-capitalize"><?php echo e($value->name); ?></td>
                            <td class="text-capitalize"><?php echo e($value->price); ?></td>
                            <td class="text-capitalize"><?php echo e($value->details); ?></td>
                            <td class="text-capitalize"><?php echo e($value->subcatname); ?></td>
                            <td class="text-capitalize"><?php echo e($value->quantity); ?></td>
                            <td><img src="<?php echo e(URL::asset('img/product/' . $value->img1)); ?>" width="150px" alt=""></td>
                            <td class="text-capitalize"><?php echo e($value->shopid); ?></td>
                            <td><a href="<?php echo e(URL::to('admin_product/' . $value->id)); ?>"
                                    class="btn btn-danger">Delete</a></td>
                        </tr>
                        <?php
                            $i++;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>
    </div>

    <!-- /page content -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminfooter','data' => []]); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/muneeb/Desktop/rentalsystem/resources/views/adminpanel/products.blade.php ENDPATH**/ ?>