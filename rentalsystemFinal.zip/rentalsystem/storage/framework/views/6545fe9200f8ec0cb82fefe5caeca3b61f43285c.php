<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminheader','data' => ['title' => 'Pending Withdraw']]); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Pending Withdraw']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>



<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Pending Withdraw <small></h3>
            </div>

        </div>

        <br><br><br>

        <a href="<?php echo e(URL::to('withdraw_table')); ?>" class="btn btn-primary">Completed Withdraw
            Requests
            <span class="badge badge-danger"><?php echo e($CompletedWithdrawCount); ?></span></a>
        <br><br>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <br><br>
                    <div class="x_content">

                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr style="color:black">
                                    <th>#No</th>
                                    <th>ShopName</th>
                                    <th>ShopEmail</th>
                                    <th>WithDrawTo</th>
                                    <th>Phone Number</th>
                                    <th>Withdraw Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $PendingWithdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr  style="color:black">
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($value->shopname); ?></td>
                                        <td><?php echo e($value->email); ?></td>
                                        <td><?php echo e($value->withdrawto); ?></td>
                                        <td><?php echo e($value->phonenumber); ?></td>
                                        <td><?php echo e($value->withdrawamount); ?></td>
                                        <td><?php echo e($value->AmountStatus); ?></td>
                                        <td><a href="<?php echo e(URL::to('confirm_withdraw/' . $value->id . '/' . $value->email)); ?>"
                                                class="btn btn-primary">Confirm</a>
                                            <a href="<?php echo e(URL::to('cancel_withdraw/' . $value->id . '/' . $value->email)); ?>"
                                                class="btn btn-danger">Cancel</a>
                                        </td>

                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>





        </div>
    </div>
    <!-- /page content -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminfooter','data' => []]); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/muneeb/Desktop/rentalsystem/resources/views/adminpanel/pending_withdraw.blade.php ENDPATH**/ ?>