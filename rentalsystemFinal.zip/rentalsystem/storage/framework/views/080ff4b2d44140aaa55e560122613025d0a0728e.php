<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminheader','data' => ['title' => 'Dashboard']]); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Dashboard</h3>
            </div>
        </div>
        <br><br><br>


        <a href="<?php echo e(URL::to('admin_view_pending_requests')); ?>" class="btn btn-primary">Pending
            Requests
            <span class="badge badge-danger"><?php echo e($CountPendingRequests); ?></span></a>
        <br><br>
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr style="color:black">
                        <th>#</th>
                        <th>Shopkeeper Name</th>
                        <th>Phone No</th>
                        <th>CNIC</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Shop Name</th>
                        <th>Shop Address</th>
                        <th>Delete</th>
                        <th>Block/UnBlock</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $allShops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="color:black">
                            <th scope="row"><?php echo e($i); ?></th>
                            <td class="text-capitalize"><?php echo e($value->fname . '' . $value->lname); ?></td>
                            <td><?php echo e($value->phoneno); ?></td>
                            <td><?php echo e($value->cnic); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->password); ?></td>
                            <td class="text-capitalize"><?php echo e($value->shopname); ?></td>
                            <td><?php echo e($value->shopaddress); ?></td>
                            <td><a href="<?php echo e(URL::asset('/admin_delete_shop/' . $value->id)); ?>"
                                    class="btn btn-danger">Delete</a></td>
                            <?php if($value->status == 1): ?>
                                <td><a href="<?php echo e(URL::to('admin_unblock_shop/' . $value->id)); ?>"
                                        class="btn btn-primary">UnBlock</a></td>
                            <?php else: ?>
                                <td><a href="<?php echo e(URL::to('admin_block_shop/' . $value->id)); ?>"
                                        class="btn btn-primary">Block</a></td>
                            <?php endif; ?>


                        </tr>
                        <?php
                            $i++;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>

    <!-- /page content -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adminfooter','data' => []]); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/muneeb/Desktop/rentalsystem/resources/views/adminpanel/index.blade.php ENDPATH**/ ?>