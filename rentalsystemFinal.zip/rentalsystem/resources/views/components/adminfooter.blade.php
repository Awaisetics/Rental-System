
       
      </div>
    </div>

    <!-- jQuery -->
    <script src="{{URL::asset('adminpanel/vendors/jquery/dist/jquery.min.js')}}"></script>
    <!-- Bootstrap -->
    <script src="{{URL::asset('adminpanel/vendors/bootstrap/dist/js/bootstrap.min.js')}}"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="{{URL::asset('adminpanel/build/js/custom.min.js')}}"></script>
	
  </body>
</html>
